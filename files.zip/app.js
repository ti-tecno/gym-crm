'use strict';
const express        = require('express');
const helmet         = require('helmet');
const cors           = require('cors');
const cookieParser   = require('cookie-parser');
const compression    = require('compression');
const mongoSanitize  = require('express-mongo-sanitize');
const hpp            = require('hpp');
const { v4: uuidv4 } = require('uuid');

const logger         = require('./config/logger');
const errorHandler   = require('./middleware/errorHandler');
const { globalRateLimit } = require('./middleware/rateLimit');

// Routes
const authRoutes    = require('./routes/auth.routes');
const userRoutes    = require('./routes/users.routes');
const memberRoutes  = require('./routes/members.routes');
const classRoutes   = require('./routes/classes.routes');

const app = express();

// ─── 1. Request ID (trazabilidad) ─────────────────────────────────────────────
app.use((req, _res, next) => {
  req.id = uuidv4();
  next();
});

// ─── 2. Helmet — Cabeceras de seguridad ──────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc:    ["'none'"],
      scriptSrc:     ["'self'"],
      styleSrc:      ["'self'"],
      imgSrc:        ["'self'", 'data:'],
      connectSrc:    ["'self'"],
      fontSrc:       ["'self'"],
      objectSrc:     ["'none'"],
      mediaSrc:      ["'none'"],
      frameSrc:      ["'none'"],
      frameAncestors:["'none'"],
      formAction:    ["'self'"],
      upgradeInsecureRequests: process.env.NODE_ENV === 'production' ? [] : undefined,
    },
  },
  hsts: {
    maxAge: 31_536_000,
    includeSubDomains: true,
    preload: true,
  },
  referrerPolicy:       { policy: 'strict-origin-when-cross-origin' },
  frameguard:           { action: 'deny' },
  noSniff:              true,
  xssFilter:            true,
  permittedCrossDomainPolicies: { permittedPolicies: 'none' },
}));

// ─── 3. CORS ──────────────────────────────────────────────────────────────────
const allowedOrigins = (process.env.ALLOWED_ORIGINS || 'http://localhost:3000')
  .split(',')
  .map(o => o.trim());

app.use(cors({
  origin: (origin, callback) => {
    if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
    logger.warn('CORS bloqueado', { origin });
    callback(new Error('CORS: origen no permitido'));
  },
  methods:            ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders:     ['Content-Type', 'Authorization', 'X-CSRF-Token', 'X-Request-ID'],
  exposedHeaders:     ['X-Request-ID'],
  credentials:        true,
  maxAge:             600,
}));

// ─── 4. Body parsing con límite de tamaño ────────────────────────────────────
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));

// ─── 5. Cookie parser ────────────────────────────────────────────────────────
app.use(cookieParser(process.env.COOKIE_SECRET));

// ─── 6. Compresión ────────────────────────────────────────────────────────────
app.use(compression());

// ─── 7. Sanitización contra NoSQL injection ──────────────────────────────────
app.use(mongoSanitize({ replaceWith: '_' }));

// ─── 8. Protección contra HTTP Parameter Pollution ───────────────────────────
app.use(hpp({
  whitelist: ['sort', 'fields', 'page', 'limit'],
}));

// ─── 9. Rate limiting global ─────────────────────────────────────────────────
app.use(globalRateLimit);

// ─── 10. Logging de requests (sin datos sensibles) ───────────────────────────
app.use((req, _res, next) => {
  // NUNCA loggear Authorization header completo ni passwords
  logger.info('HTTP Request', {
    requestId: req.id,
    method:    req.method,
    path:      req.path,
    ip:        req.ip,
    userAgent: req.headers['user-agent']?.substring(0, 100),
  });
  next();
});

// ─── 11. Forzar HTTPS en producción ──────────────────────────────────────────
if (process.env.NODE_ENV === 'production') {
  app.use((req, res, next) => {
    if (req.secure || req.headers['x-forwarded-proto'] === 'https') return next();
    return res.redirect(301, `https://${req.headers.host}${req.url}`);
  });
}

// ─── 12. Health check (información mínima) ───────────────────────────────────
app.get('/health', (_req, res) => {
  res.status(200).json({ status: 'ok' });
});

// ─── 13. Rutas API ───────────────────────────────────────────────────────────
const API = `/api/${process.env.API_VERSION || 'v1'}`;
app.use(`${API}/auth`,    authRoutes);
app.use(`${API}/users`,   userRoutes);
app.use(`${API}/members`, memberRoutes);
app.use(`${API}/classes`, classRoutes);

// ─── 14. Ruta no encontrada ───────────────────────────────────────────────────
app.use((_req, res) => {
  res.status(404).json({ error: 'Recurso no encontrado' });
});

// ─── 15. Manejador de errores centralizado ────────────────────────────────────
app.use(errorHandler);

module.exports = app;
