# GymApp — Sistema de Gestión de Gimnasio

Stack seguro: **React + Vite** (frontend) + **Node.js / Express** (backend).

---

## 📂 Estructura del Proyecto

```
gym/
├── backend/                # API REST Node.js / Express
│   ├── scripts/
│   │   └── generateKeys.js # Genera par RSA para JWT
│   ├── src/
│   │   ├── app.js          # Express + middleware de seguridad
│   │   ├── server.js       # Entry point + graceful shutdown
│   │   ├── config/
│   │   │   ├── jwt.js      # RS256 — sign / verify tokens
│   │   │   └── logger.js   # Winston — sin datos sensibles
│   │   ├── middleware/
│   │   │   ├── auth.js     # authenticate · authorize · requirePermission
│   │   │   ├── rateLimit.js
│   │   │   ├── validate.js # Zod schemas
│   │   │   └── errorHandler.js
│   │   ├── routes/         # auth · users · members · classes
│   │   ├── controllers/
│   │   │   └── auth.controller.js  # Login · Logout · Refresh (rotación)
│   │   └── schemas/
│   │       └── auth.schema.js      # Zod
│   ├── .env.example
│   └── package.json
│
└── frontend/               # React + Vite
    ├── public/index.html   # CSP meta tags
    ├── src/
    │   ├── App.jsx         # React Router v6 + rutas protegidas
    │   ├── main.jsx
    │   ├── store/
    │   │   └── authStore.js        # Zustand — token SOLO en memoria
    │   ├── services/
    │   │   ├── api.service.js      # Axios + interceptores + silent refresh
    │   │   └── auth.service.js
    │   ├── components/
    │   │   ├── guards/
    │   │   │   ├── ProtectedRoute.jsx  # JWT expiry + RBAC check
    │   │   │   └── RoleGuard.jsx       # Render condicional por rol
    │   │   └── auth/
    │   │       └── LoginForm.jsx       # RHF + Zod + rate limit frontend
    │   ├── hooks/
    │   │   └── useSilentRefresh.js     # Auto-refresh antes de expirar
    │   ├── utils/
    │   │   ├── sanitize.js     # DOMPurify — XSS protection
    │   │   └── urlValidator.js # Open redirect protection
    │   └── schemas/
    │       └── auth.schema.js  # Zod (mirror del backend)
    ├── .env.example
    ├── vite.config.js
    └── package.json
```

---

## 🚀 Instalación

### 1. Clonar y preparar entorno

```bash
git clone <repo-url> gym
cd gym
```

### 2. Backend

```bash
cd backend
cp .env.example .env
# Editar .env con tus valores reales

npm install
node scripts/generateKeys.js   # Genera keys/private.pem y keys/public.pem
npm run dev
```

### 3. Frontend

```bash
cd ../frontend
cp .env.example .env
# Editar VITE_API_URL si cambias el puerto del backend

npm install
npm run dev
```

---

## 🔐 Decisiones de Seguridad Clave

### JWT con RS256 (Asimétrico)
- **Clave privada** en el servidor para firmar → nunca expuesta al cliente
- **Clave pública** para verificar → puede distribuirse si fuera necesario
- Access token: **15 min** (configurable via `JWT_ACCESS_TOKEN_EXPIRY`)
- Refresh token: **7 días** en cookie **HTTP-only + SameSite=Strict**

### Tokens en Memoria
```
accessToken → Zustand store (RAM) — NO localStorage, NO sessionStorage
refreshToken → Cookie HTTP-only (inaccesible para JS malicioso)
```

### Refresh Token Rotation
Cada llamada a `/auth/refresh` invalida el token anterior y emite uno nuevo.
Si se detecta **reuso** de un token ya invalidado → **toda la familia se revoca**
(protección contra robo de tokens).

### XSS (Cross-Site Scripting)
- React escapa automáticamente todo contenido renderizado via `{}`
- `dangerouslySetInnerHTML` **nunca se usa sin pasar por `sanitizeHtml()`** (DOMPurify)
- CSP configurada tanto en el HTML (`<meta>`) como en las cabeceras del servidor de desarrollo

### Open Redirect
La función `getSafeLoginRedirect()` valida el parámetro `?from=` contra una
lista de rutas internas permitidas antes de redirigir. `sanitizeRouteId()` limpia
IDs de rutas dinámicas.

### Rate Limiting — Capas
| Capa | Límite | Ventana |
|---|---|---|
| Global | 100 req | 1 min |
| `POST /auth/login` | 5 intentos | 15 min |
| `POST /auth/register` | 3 registros | 1 hora |
| Frontend LoginForm | 3 intentos | 1 min |
| Delay progresivo | +300ms/intento | — |

---

## ✅ Lista de Verificación de Seguridad

- [x] `npm audit` limpio (ejecutar antes de deploy)
- [x] HTTPS forzado en producción (redirect 301)
- [x] CSRF: SameSite=Strict en cookies de refresh token
- [x] XSS: DOMPurify + React JSX escaping automático
- [x] Rate limiting en autenticación (IP + usuario)
- [x] CSP configurada (meta + Helmet)
- [x] Secrets en variables de entorno (NUNCA en código)
- [x] Validación Zod en frontend Y backend
- [x] Logging sin datos sensibles (Winston con redactor)
- [x] JWT RS256 con expiración corta (15 min)
- [x] Refresh tokens rotados con detección de reuso
- [x] CORS lista blanca restrictiva
- [x] Helmet.js con todas las protecciones activas
- [x] Bloqueo de cuenta (5 intentos fallidos → 30 min)
- [x] Open redirect protegido (urlValidator.js)
- [x] `dangerouslySetInnerHTML` siempre con DOMPurify
- [x] Stack traces nunca expuestos en producción
- [x] Source maps deshabilitados en build de producción
- [x] Claves RSA en `.gitignore` (nunca al repositorio)
- [ ] Test de penetración con OWASP ZAP (post-deploy)
- [ ] Dependabot / Snyk configurado en CI/CD
- [ ] TLS 1.3 configurado en servidor de producción

---

## 🔄 Flujo de Autenticación

```
Usuario → POST /auth/login
         ← accessToken (JSON, 15 min)  → guardado en MEMORIA (Zustand)
         ← refreshToken (cookie HTTP-only, 7 días)

Cada request → Authorization: Bearer <accessToken>

Al expirar → interceptor Axios → POST /auth/refresh (auto, silencioso)
             ← nuevo accessToken
             ← nuevo refreshToken (cookie rotada)

Logout → DELETE token de store → clearCookie en servidor
```

---

## 🛡️ Cabeceras de Seguridad (Helmet)

```
Content-Security-Policy: default-src 'none'; script-src 'self'; ...
Strict-Transport-Security: max-age=31536000; includeSubDomains; preload
X-Frame-Options: DENY
X-Content-Type-Options: nosniff
Referrer-Policy: strict-origin-when-cross-origin
Permissions-Policy: camera=(), microphone=(), geolocation=()
```
