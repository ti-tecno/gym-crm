/**
 * sanitize.js
 * Sanitización de inputs con DOMPurify.
 * ─── Regla de oro ────────────────────────────────────────────────
 * NUNCA usar dangerouslySetInnerHTML sin pasar antes por sanitize().
 * En React, usar {} para renderizado es suficiente para texto plano.
 * sanitize() solo se necesita cuando debes renderizar HTML enriquecido.
 * ─────────────────────────────────────────────────────────────────
 */
import DOMPurify from 'dompurify';

// Configuración estricta de DOMPurify
const STRICT_CONFIG = {
  ALLOWED_TAGS:  ['b', 'i', 'em', 'strong', 'p', 'br', 'ul', 'ol', 'li', 'span'],
  ALLOWED_ATTR:  ['class'],
  FORBID_SCRIPTS: true,
  FORBID_ATTR:   ['style', 'onerror', 'onload', 'onclick', 'onmouseover'],
  KEEP_CONTENT:  true,
};

/**
 * Sanitiza HTML enriquecido antes de renderizar con dangerouslySetInnerHTML.
 * @param {string} dirty — HTML potencialmente peligroso
 * @returns {{ __html: string }} — objeto seguro para dangerouslySetInnerHTML
 *
 * @example
 * // ❌ PELIGROSO — nunca hacer esto:
 * <div dangerouslySetInnerHTML={{ __html: userInput }} />
 *
 * // ✅ CORRECTO — siempre sanitizar:
 * <div dangerouslySetInnerHTML={sanitizeHtml(userInput)} />
 */
export const sanitizeHtml = (dirty) => ({
  __html: DOMPurify.sanitize(dirty ?? '', STRICT_CONFIG),
});

/**
 * Sanitiza un string para uso como texto plano (elimina TODA etiqueta HTML).
 * Usar cuando el input se mostrará como texto, no como HTML.
 */
export const sanitizeText = (input) => {
  if (typeof input !== 'string') return '';
  return DOMPurify.sanitize(input, { ALLOWED_TAGS: [], ALLOWED_ATTR: [] });
};

/**
 * Sanitiza un objeto de formulario: aplica sanitizeText a cada campo string.
 * Útil antes de enviar datos al backend.
 */
export const sanitizeFormData = (data) => {
  if (!data || typeof data !== 'object') return {};
  return Object.fromEntries(
    Object.entries(data).map(([key, value]) => [
      key,
      typeof value === 'string' ? sanitizeText(value) : value,
    ])
  );
};

/**
 * Sanitiza un array de objetos.
 */
export const sanitizeArray = (arr) => {
  if (!Array.isArray(arr)) return [];
  return arr.map((item) =>
    typeof item === 'string' ? sanitizeText(item) : sanitizeFormData(item)
  );
};
