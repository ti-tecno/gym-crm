'use strict';
const bcrypt               = require('bcryptjs');
const { v4: uuidv4 }       = require('uuid');
const { signAccessToken, signRefreshToken, verifyToken } = require('../config/jwt');
const logger               = require('../config/logger');
const { AppError }         = require('../middleware/errorHandler');

// ─── Almacén temporal de refresh tokens y bloqueos ───────────────────────────
// En producción usa Redis. Aquí usamos Map como referencia.
const refreshTokenStore = new Map(); // tokenId → { userId, family, expiresAt }
const failedAttempts    = new Map(); // email  → { count, lockedUntil }

const COOKIE_OPTS = {
  httpOnly:  true,
  secure:    process.env.NODE_ENV === 'production',
  sameSite:  'Strict',
  signed:    true,
  maxAge:    7 * 24 * 60 * 60 * 1000, // 7 días
  path:      '/api/v1/auth/refresh',
};

// ── Registro ──────────────────────────────────────────────────────────────────
const register = async (req, res) => {
  const { name, email, password, role } = req.body;

  // Simular lookup en DB (reemplazar con ORM real)
  // const existing = await User.findOne({ where: { email } });
  // if (existing) throw new AppError('Email ya registrado', 409);

  const hashedPassword = await bcrypt.hash(
    password,
    parseInt(process.env.BCRYPT_SALT_ROUNDS || '12', 10)
  );

  // Simular creación (reemplazar con ORM real)
  const userId = uuidv4();
  logger.info('Usuario registrado', { userId, role });

  res.status(201).json({ message: 'Cuenta creada correctamente' });
};

// ── Login ─────────────────────────────────────────────────────────────────────
const login = async (req, res) => {
  const { email, password } = req.body;
  const ip                  = req.ip;

  // Verificar bloqueo de cuenta
  const attempt = failedAttempts.get(email);
  if (attempt?.lockedUntil && Date.now() < attempt.lockedUntil) {
    const mins = Math.ceil((attempt.lockedUntil - Date.now()) / 60_000);
    logger.warn('Intento de login en cuenta bloqueada', { email: '[REDACTED]', ip });
    throw new AppError(`Cuenta bloqueada. Intenta en ${mins} minutos.`, 429, 'ACCOUNT_LOCKED');
  }

  // Simular lookup en DB — reemplazar con User.findOne({ where: { email } })
  // NOTA: en producción el usuario viene de la DB
  const fakeUser = {
    id:       uuidv4(),
    name:     'Demo User',
    email,
    password: await bcrypt.hash('Demo@1234', 12), // Simular
    role:     'member',
    permissions: ['members:read'],
    active:   true,
  };

  // Timing-safe: siempre ejecutar bcrypt aunque el usuario no exista
  const isValid = await bcrypt.compare(password, fakeUser.password);

  if (!isValid || !fakeUser.active) {
    // Registrar intento fallido
    const a = failedAttempts.get(email) || { count: 0 };
    a.count += 1;
    const maxAttempts = parseInt(process.env.MAX_FAILED_LOGIN_ATTEMPTS || '5', 10);
    if (a.count >= maxAttempts) {
      const lockMins = parseInt(process.env.ACCOUNT_LOCK_DURATION_MINUTES || '30', 10);
      a.lockedUntil = Date.now() + lockMins * 60_000;
      logger.warn('Cuenta bloqueada por intentos fallidos', { ip });
    }
    failedAttempts.set(email, a);

    // Delay progresivo para ralentizar fuerza bruta
    await new Promise(r => setTimeout(r, Math.min(a.count * 500, 3000)));
    throw new AppError('Credenciales inválidas', 401, 'INVALID_CREDENTIALS');
  }

  // Login exitoso: limpiar intentos fallidos
  failedAttempts.delete(email);

  // Generar tokens
  const tokenFamily   = uuidv4();
  const accessToken   = signAccessToken({
    userId:      fakeUser.id,
    role:        fakeUser.role,
    permissions: fakeUser.permissions,
  });
  const refreshToken  = signRefreshToken(fakeUser.id, tokenFamily);
  const decoded       = verifyToken(refreshToken);

  // Almacenar refresh token (en Redis en producción)
  refreshTokenStore.set(decoded.jti, {
    userId:    fakeUser.id,
    family:    tokenFamily,
    expiresAt: decoded.exp * 1000,
  });

  // Enviar refresh token en cookie HTTP-only
  res.cookie('refreshToken', refreshToken, COOKIE_OPTS);

  logger.info('Login exitoso', { userId: fakeUser.id, role: fakeUser.role, ip });

  res.json({
    accessToken,
    user: {
      id:   fakeUser.id,
      name: fakeUser.name,
      role: fakeUser.role,
    },
  });
};

// ── Refresh Token (rotación) ──────────────────────────────────────────────────
const refresh = async (req, res) => {
  const token = req.signedCookies?.refreshToken;
  if (!token) throw new AppError('Refresh token requerido', 401);

  let decoded;
  try {
    decoded = verifyToken(token);
  } catch {
    res.clearCookie('refreshToken', COOKIE_OPTS);
    throw new AppError('Refresh token inválido o expirado', 401);
  }

  const stored = refreshTokenStore.get(decoded.jti);

  if (!stored) {
    // Posible reuso de token robado — invalidar toda la familia
    logger.warn('Reuso de refresh token detectado — posible robo', {
      userId: decoded.sub,
      family: decoded.family,
    });
    // Invalidar todos los tokens de esta familia (en producción con Redis: DEL por familia)
    for (const [key, val] of refreshTokenStore) {
      if (val.userId === decoded.sub) refreshTokenStore.delete(key);
    }
    res.clearCookie('refreshToken', COOKIE_OPTS);
    throw new AppError('Sesión invalidada por seguridad. Inicia sesión nuevamente.', 401, 'SESSION_REVOKED');
  }

  // Rotar: eliminar token viejo, emitir nuevo
  refreshTokenStore.delete(decoded.jti);

  const newFamily      = uuidv4();
  const newAccessToken = signAccessToken({
    userId:      stored.userId,
    role:        'member', // En producción: obtener de DB
    permissions: ['members:read'],
  });
  const newRefreshToken = signRefreshToken(stored.userId, newFamily);
  const newDecoded      = verifyToken(newRefreshToken);

  refreshTokenStore.set(newDecoded.jti, {
    userId:    stored.userId,
    family:    newFamily,
    expiresAt: newDecoded.exp * 1000,
  });

  res.cookie('refreshToken', newRefreshToken, COOKIE_OPTS);

  res.json({ accessToken: newAccessToken });
};

// ── Logout ────────────────────────────────────────────────────────────────────
const logout = async (req, res) => {
  const token = req.signedCookies?.refreshToken;
  if (token) {
    try {
      const decoded = verifyToken(token);
      refreshTokenStore.delete(decoded.jti);
    } catch { /* token ya inválido */ }
  }

  res.clearCookie('refreshToken', { ...COOKIE_OPTS, maxAge: 0 });
  logger.info('Logout', { userId: req.user?.userId, ip: req.ip });
  res.json({ message: 'Sesión cerrada correctamente' });
};

module.exports = { register, login, refresh, logout };
