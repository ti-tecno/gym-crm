/**
 * urlValidator.js
 * Valida que URLs y parámetros de routing provengan de fuentes confiables.
 * ─── Protecciones ─────────────────────────────────────────────────
 * • Previene Open Redirect (redirigir a dominios maliciosos)
 * • Valida que paths internos sean rutas válidas de la app
 * • Sanitiza query params antes de usar en componentes
 * • Previene javascript: y data: URIs
 * ─────────────────────────────────────────────────────────────────
 */

/** Rutas internas permitidas en la aplicación */
const ALLOWED_INTERNAL_PATHS = new Set([
  '/',
  '/login',
  '/register',
  '/dashboard',
  '/members',
  '/classes',
  '/profile',
  '/schedule',
  '/settings',
]);

/** Dominios externos de confianza (solo si necesitas redirigir externamente) */
const TRUSTED_EXTERNAL_DOMAINS = new Set([
  // Agregar solo si es necesario, ej: 'yourdomain.com'
]);

/** Protocolos prohibidos */
const DANGEROUS_PROTOCOLS = /^(javascript|data|vbscript|file):/i;

/**
 * Verifica si una URL es segura para redirigir.
 * Previene ataques de Open Redirect.
 *
 * @param {string} url — URL a validar
 * @returns {boolean}
 *
 * @example
 * // ❌ PELIGROSO — nunca hacer:
 * navigate(searchParams.get('redirect'));
 *
 * // ✅ CORRECTO:
 * const redirectTo = searchParams.get('redirect');
 * if (isSafeRedirectUrl(redirectTo)) navigate(redirectTo);
 * else navigate('/dashboard');
 */
export const isSafeRedirectUrl = (url) => {
  if (!url || typeof url !== 'string') return false;

  const trimmed = url.trim();

  // Bloquear protocolos peligrosos
  if (DANGEROUS_PROTOCOLS.test(trimmed)) return false;

  // Rutas relativas internas (empiezan con /)
  if (trimmed.startsWith('/')) {
    // Prevenir protocol-relative URLs (//)
    if (trimmed.startsWith('//')) return false;
    // Validar contra lista de rutas permitidas
    const basePath = trimmed.split('?')[0].split('#')[0];
    return ALLOWED_INTERNAL_PATHS.has(basePath) ||
           basePath.startsWith('/members/') ||
           basePath.startsWith('/classes/');
  }

  // URLs absolutas: solo dominios de confianza
  try {
    const parsed = new URL(trimmed);
    if (!['http:', 'https:'].includes(parsed.protocol)) return false;
    return TRUSTED_EXTERNAL_DOMAINS.has(parsed.hostname);
  } catch {
    return false;
  }
};

/**
 * Obtiene el valor de un query param y lo sanitiza.
 * Nunca retorna valores vacíos ni peligrosos.
 *
 * @param {URLSearchParams} params
 * @param {string} key
 * @param {string} fallback — valor seguro por defecto
 * @returns {string}
 */
export const getSafeQueryParam = (params, key, fallback = '') => {
  const value = params.get(key);
  if (!value) return fallback;

  // Eliminar caracteres de control y HTML
  const sanitized = value
    .replace(/[\x00-\x1F\x7F]/g, '')
    .replace(/[<>"'`]/g, '')
    .trim()
    .substring(0, 500); // Limitar longitud

  return sanitized || fallback;
};

/**
 * Sanitiza un ID de parámetro de ruta (solo alfanumérico + guiones).
 * Previene path traversal y parameter injection.
 *
 * @param {string} id — valor de req.params.id o similar
 * @returns {string | null} — ID sanitizado o null si es inválido
 *
 * @example
 * const memberId = sanitizeRouteId(params.id);
 * if (!memberId) return navigate('/404');
 */
export const sanitizeRouteId = (id) => {
  if (!id || typeof id !== 'string') return null;
  const clean = id.replace(/[^a-zA-Z0-9\-_]/g, '').substring(0, 100);
  return clean.length > 0 ? clean : null;
};

/**
 * Construye una URL de redirección segura después del login.
 * Usa el parámetro `from` solo si apunta a una ruta interna válida.
 */
export const getSafeLoginRedirect = (searchParams) => {
  const from = getSafeQueryParam(searchParams, 'from', '/dashboard');
  return isSafeRedirectUrl(from) ? from : '/dashboard';
};
